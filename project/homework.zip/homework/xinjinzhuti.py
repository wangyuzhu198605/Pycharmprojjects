import requests
import xlrd
excel = xlrd.open_workbook('/Users/wangyuzhu/PycharmProjects/untitled1/homework/test.xlsx')
#新建主题接口
sheet= excel.sheets()[1]
print(sheet.nrows)
def test_xinjianzhuti(url,**data):
    r=requests.post(url,data=data)
    return r.json()
for  i  in range(3,sheet.nrows):
    accesstoken=sheet.row_values(i)[0]
    print(accesstoken)
    title=sheet.row_values(i)[1]
    tab=sheet.row_values(i)[2]
    content=sheet.row_values(i)[3]
    test_xinjianzhuti(url='http://39.107.96.138:3000/api/v1',accesstoken=accesstoken,title=title,tab=tab,content=content)